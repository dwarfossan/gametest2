// ============================================================
// ui.js — 畫面渲染
// ============================================================

// 場景切換
function showScene(id) {
  document.querySelectorAll('.scene').forEach(s => s.classList.remove('on'));
  const sc = document.getElementById('sc-' + id);
  if (sc) sc.classList.add('on');
  G.scene = id;
}

// 角色色塊
function makeSprite(color, size = 80) {
  return `<div style="width:${size}px;height:${size}px;background:${color};border:2px solid #111;display:inline-block;"></div>`;
}

// HP 條
function hpBar(current, max, color = '#bb2222') {
  const pct = Math.max(0, current / max * 100);
  return `<div style="background:#333;height:8px;width:100%;border:1px solid #111;">
    <div style="width:${pct}%;height:100%;background:${color};transition:width .3s;"></div>
  </div>`;
}

// 戰鬥畫面 — 我方（左邊）
function renderParty() {
  const wrap = document.getElementById('ui-party');
  if (!wrap) return;
  wrap.innerHTML = '';
  G.party.forEach((member, i) => {
    const div = document.createElement('div');
    div.className = 'slot-card';
    if (!member) {
      div.innerHTML = `<div class="slot-empty">空</div>`;
    } else {
      div.innerHTML = `
        <div class="slot-name">${member.name}</div>
        ${makeSprite(member.color || CONFIG.COLORS.PLAYER, 60)}
        ${hpBar(member.hp, member.maxHp)}
        <div class="slot-hp">${member.hp}/${member.maxHp}</div>
      `;
    }
    wrap.appendChild(div);
  });
}

// 戰鬥畫面 — 敵方（右邊）
function renderEnemies() {
  const wrap = document.getElementById('ui-enemies');
  if (!wrap) return;
  wrap.innerHTML = '';
  G.combat.enemies.forEach((enemy, i) => {
    const div = document.createElement('div');
    div.className = 'slot-card';
    if (!enemy || enemy.hp <= 0) {
      div.innerHTML = `<div class="slot-empty">空</div>`;
    } else {
      div.innerHTML = `
        <div class="slot-name">${enemy.name}</div>
        ${makeSprite(enemy.color || CONFIG.COLORS.ENEMY, 60)}
        ${hpBar(enemy.hp, enemy.maxHp)}
        <div class="slot-hp">${enemy.hp}/${enemy.maxHp}</div>
      `;
      div.style.cursor = 'pointer';
      div.onclick = () => onEnemyClick(i);
    }
    wrap.appendChild(div);
  });
}

// 戰鬥 log
function renderLog() {
  const el = document.getElementById('ui-log');
  if (!el || !G.combat) return;
  const last5 = G.combat.log.slice(-5);
  el.innerHTML = last5.map(l => `<div>${l}</div>`).join('');
}

// 玩家狀態列
function renderPlayerStatus() {
  const p = G.player;
  if (!p) return;
  const el = document.getElementById('ui-status');
  if (!el) return;
  el.innerHTML = `
    HP: ${p.hp}/${p.maxHp} &nbsp;|&nbsp;
    ⚔️ skill:${p.skill} &nbsp;
    🛡️ def:${p.def} &nbsp;
    🍀 luck:${p.luck} &nbsp;|&nbsp;
    🪙 ${p.gp}gp
  `;
}

// 點擊敵人
function onEnemyClick(slot) {
  if (!G.combat || G.combat.phase !== 'player') return;
  const result = playerAttack(slot);
  if (!result) return;
  renderEnemies();
  renderLog();
  renderPlayerStatus();

  const end = checkBattleEnd();
  if (end === 'win') {
    setTimeout(() => alert('勝利！'), 300);
    return;
  }

  // 敵方回合
  G.combat.phase = 'enemy';
  setTimeout(() => {
    G.combat.enemies.forEach((e, i) => {
      if (e && e.hp > 0) enemyAttack(i);
    });
    renderParty();
    renderLog();
    renderPlayerStatus();
    G.combat.phase = 'player';
    G.combat.turn++;

    if (checkBattleEnd() === 'lose') {
      setTimeout(() => alert('敗北...'), 300);
    }
  }, 600);
}
