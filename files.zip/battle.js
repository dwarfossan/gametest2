// ============================================================
// battle.js — 戰鬥邏輯
// ============================================================

// 骰子
function roll(sides) {
  return Math.floor(Math.random() * sides) + 1;
}

// 武器骰
function rollWeaponDice(weaponType, crit = false) {
  const mult = crit ? 2 : 1;
  switch (weaponType) {
    case 'LIGHT':    return roll(4)  * mult;
    case 'MILITARY': return (roll(6)) * mult;
    case 'HEAVY':    return (roll(6) + roll(6)) * mult;
    case 'RANGED':   return roll(8)  * mult;
    default:         return roll(4)  * mult;
  }
}

// 命中判定
function checkHit(attackerSkill, defenderDef) {
  const d20 = roll(20);
  const total = d20 + attackerSkill;
  const crit  = d20 === CONFIG.COMBAT.CRIT_THRESHOLD;
  const hit   = crit || total > defenderDef;
  return { d20, total, hit, crit };
}

// 玩家攻擊敵人
function playerAttack(targetSlot) {
  const p = G.player;
  const enemies = G.combat.enemies;
  const target  = enemies[targetSlot];
  if (!target || target.hp <= 0) return null;

  const weaponType = p.eq.weapon ? p.eq.weapon.dice : 'MILITARY';
  const { d20, total, hit, crit } = checkHit(p.skill, target.def);

  let dmg = 0;
  let log = '';

  if (hit) {
    dmg = rollWeaponDice(weaponType, crit) + p.skill;
    target.hp = Math.max(0, target.hp - dmg);
    log = crit
      ? `暴擊！${target.name} 受到 ${dmg} 點傷害！`
      : `命中！${target.name} 受到 ${dmg} 點傷害！`;
  } else {
    log = `未命中（1d20(${d20})+${p.skill}=${total} vs ${target.def}）`;
  }

  G.combat.log.push(log);
  return { hit, crit, dmg, log };
}

// 敵人攻擊玩家
function enemyAttack(enemySlot) {
  const enemy = G.combat.enemies[enemySlot];
  if (!enemy || enemy.hp <= 0) return null;

  const p = G.player;
  const { d20, total, hit, crit } = checkHit(enemy.skill, p.def);

  let dmg = 0;
  let log = '';

  if (hit) {
    dmg = rollWeaponDice(enemy.weapon || 'MILITARY', crit) + enemy.skill;
    p.hp = Math.max(0, p.hp - dmg);
    log = crit
      ? `${enemy.name} 暴擊！你受到 ${dmg} 點傷害！`
      : `${enemy.name} 命中！你受到 ${dmg} 點傷害！`;
  } else {
    log = `${enemy.name} 未命中（${total} vs ${p.def}）`;
  }

  G.combat.log.push(log);
  return { hit, crit, dmg, log };
}

// 生成敵人（帶等級縮放）
function spawnEnemy(key, level = 1) {
  const base  = DB_ENEMY[key];
  const scale = 1 + (level - 1) * CONFIG.SCALING.ENEMY_SCALE;
  return {
    ...base,
    hp:    Math.round(base.hp * scale),
    maxHp: Math.round(base.hp * scale),
    skill: Math.round(base.skill * scale),
    def:   Math.round(base.def  * scale),
    status: [],
  };
}

// 初始化戰鬥
function initCombat(enemyKeys) {
  const level = G.player.level || 1;
  G.combat = {
    enemies: [null, null, null, null],
    turn: 0,
    phase: 'player',
    log: [],
  };
  enemyKeys.forEach((key, i) => {
    if (i < 4 && key) G.combat.enemies[i] = spawnEnemy(key, level);
  });
}

// 戰鬥結束判定
function checkBattleEnd() {
  const allEnemiesDead = G.combat.enemies.every(e => !e || e.hp <= 0);
  const playerDead     = G.player.hp <= 0;
  if (allEnemiesDead) return 'win';
  if (playerDead)     return 'lose';
  return null;
}
